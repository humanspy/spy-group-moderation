import { promises as fs } from 'fs';
import bcrypt from 'bcrypt';

async function loadUsers() {
  try {
    const data = await fs.readFile('./users.json', 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error loading users:', error);
    return {};
  }
}

async function testLogin() {
  console.log('Testing authentication system...\n');
  
  const users = await loadUsers();
  console.log('Total users loaded:', Object.keys(users).length);
  console.log('Users:', Object.values(users).map(u => u.username));
  
  const username = 'human_spy';
  const password = '123456789';
  
  // Find user
  const userEntry = Object.values(users).find((u) => u.username.toLowerCase() === username.toLowerCase());
  
  if (!userEntry) {
    console.log('\n❌ User not found!');
    return;
  }
  
  console.log('\n✅ User found:', userEntry.username);
  console.log('Stored hash:', userEntry.password);
  
  // Test password
  const isValid = await bcrypt.compare(password, userEntry.password);
  console.log('\nPassword match result:', isValid);
  
  if (isValid) {
    console.log('✅ Authentication would succeed!');
  } else {
    console.log('❌ Authentication would fail!');
  }
}

testLogin();
