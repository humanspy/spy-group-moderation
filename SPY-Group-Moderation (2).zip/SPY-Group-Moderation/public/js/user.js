let currentUser = null;
let userId = null;
let userCases = [];
window.currentUser = null;

async function checkAuth() {
  try {
    const response = await fetch('/api/session');
    if (!response.ok) {
      window.location.href = '/login.html';
      return false;
    }
    const data = await response.json();
    currentUser = data.user;
    window.currentUser = data.user;
    updateUserInfo();
    return true;
  } catch (error) {
    window.location.href = '/login.html';
    return false;
  }
}

function updateUserInfo() {
  if (currentUser) {
    const userInfo = document.getElementById('userInfo');
    userInfo.innerHTML = `
      <img src="${currentUser.avatar}" alt="${currentUser.username}" class="nav-avatar">
      <span style="color: ${currentUser.roleColor || '#99aab5'}">
        ${currentUser.username} ${currentUser.role ? `(${currentUser.role})` : ''}
      </span>
    `;
  }
}

function normalizeType(type) {
  const typeMap = {
    'warn': 'Warning',
    'warning': 'Warning',
    'timeout': 'Timeout',
    'kick': 'Kick',
    'ban': 'Ban',
    'hackban': 'Hackban'
  };
  return typeMap[type.toLowerCase()] || type;
}

function getTypeClass(type) {
  const classMap = {
    'warn': 'warning',
    'warning': 'warning',
    'timeout': 'timeout',
    'kick': 'kick',
    'ban': 'ban',
    'hackban': 'hackban'
  };
  return classMap[type.toLowerCase()] || type.toLowerCase();
}

async function loadUserProfile() {
  const urlParams = new URLSearchParams(window.location.search);
  userId = urlParams.get('id');
  
  if (!userId) {
    document.getElementById('userProfileHeader').innerHTML = `
      <div class="no-cases">
        <h2>Invalid User</h2>
        <p>No user ID provided.</p>
      </div>
    `;
    return;
  }
  
  try {
    const response = await fetch(`/api/user/${userId}`);
    if (!response.ok) throw new Error('Failed to load user data');
    
    const data = await response.json();
    userCases = data.cases || [];
    
    displayUserHeader(data.user, userCases);
    updateUserStats(userCases);
    displayUserCases(userCases);
  } catch (error) {
    document.getElementById('userProfileHeader').innerHTML = `
      <div class="no-cases">
        <h2>Error loading user</h2>
        <p>${error.message}</p>
      </div>
    `;
  }
}

function displayUserHeader(user, cases) {
  const header = document.getElementById('userProfileHeader');
  header.innerHTML = `
    <div class="user-profile-card">
      <img src="${user.avatar}" alt="${escapeHtml(user.username)}" class="user-profile-avatar">
      <div class="user-profile-info">
        <h2>${escapeHtml(user.username)}</h2>
        <p class="user-id">Discord ID: ${user.id}</p>
        <p class="case-count">${cases.length} moderation case${cases.length !== 1 ? 's' : ''}</p>
      </div>
    </div>
  `;
}

function updateUserStats(cases) {
  const stats = {
    total: cases.length,
    warning: 0,
    timeout: 0,
    kick: 0,
    ban: 0,
  };
  
  cases.forEach(c => {
    const type = c.type.toLowerCase();
    if (type === 'warning' || type === 'warn') stats.warning++;
    else if (type === 'timeout') stats.timeout++;
    else if (type === 'kick') stats.kick++;
    else if (type === 'ban' || type === 'hackban') stats.ban++;
  });
  
  document.getElementById('userTotalCases').textContent = stats.total;
  document.getElementById('userWarningCount').textContent = stats.warning;
  document.getElementById('userTimeoutCount').textContent = stats.timeout;
  document.getElementById('userKickCount').textContent = stats.kick;
  document.getElementById('userBanCount').textContent = stats.ban;
  
  document.getElementById('userStatsGrid').style.display = 'grid';
}

function displayUserCases(cases) {
  const container = document.getElementById('userCasesContainer');
  
  if (cases.length === 0) {
    container.innerHTML = `
      <div class="no-cases">
        <h2>📋 No cases found</h2>
        <p>This user has no moderation history.</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = `
    <div class="table-container">
      <table class="cases-table">
        <thead>
          <tr>
            <th>Case #</th>
            <th>Type</th>
            <th>Moderator</th>
            <th>Reason</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          ${cases.map(c => {
            const modName = escapeHtml(c.moderatorName);
            const modAvatar = c.moderatorAvatar || 'https://cdn.discordapp.com/embed/avatars/1.png';
            const reason = escapeHtml(c.reason || 'No reason provided');
            const dateStr = new Date(c.timestamp).toLocaleString();
            
            return `<tr class="clickable-row" onclick='showCaseModal(${JSON.stringify(c).replace(/'/g, "&apos;")})'>
              <td class="case-number-cell">#${c.caseNumber}</td>
              <td class="type-cell"><span class="case-type ${getTypeClass(c.type)}">${normalizeType(c.type)}</span></td>
              <td class="moderator-cell">
                <img src="${modAvatar}" alt="${modName}" class="table-avatar">
                <span>${modName}</span>
              </td>
              <td class="reason-cell">${reason}</td>
              <td class="date-cell">${dateStr}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login.html';
  } catch (error) {
    window.location.href = '/login.html';
  }
});

(async () => {
  if (await checkAuth()) {
    await loadUserProfile();
  }
})();
