let allCases = [];
let currentUser = null;
window.currentUser = null;

async function checkAuth() {
  try {
    const response = await fetch('/api/session');
    if (!response.ok) {
      window.location.href = '/login.html';
      return false;
    }
    const data = await response.json();
    currentUser = data.user;
    window.currentUser = data.user;
    updateUserInfo();
    return true;
  } catch (error) {
    window.location.href = '/login.html';
    return false;
  }
}

function updateUserInfo() {
  if (currentUser) {
    const userInfo = document.getElementById('userInfo');
    userInfo.innerHTML = `
      <img src="${currentUser.avatar}" alt="${currentUser.username}" class="nav-avatar">
      <span style="color: ${currentUser.roleColor || '#99aab5'}">
        ${currentUser.username} ${currentUser.role ? `(${currentUser.role})` : ''}
      </span>
    `;
  }
}

async function loadCases() {
  try {
    const response = await fetch('/api/cases');
    if (!response.ok) throw new Error('Failed to load cases');
    
    const data = await response.json();
    allCases = data.cases || [];
    
    updateStats(allCases);
    displayCases(allCases);
  } catch (error) {
    document.getElementById('casesContainer').innerHTML = `
      <div class="no-cases">
        <h2>Error loading cases</h2>
        <p>${error.message}</p>
      </div>
    `;
  }
}

function updateStats(cases) {
  const stats = {
    total: cases.length,
    warning: 0,
    timeout: 0,
    kick: 0,
    ban: 0,
  };
  
  cases.forEach(c => {
    const type = c.type.toLowerCase();
    if (type === 'warning') stats.warning++;
    else if (type === 'timeout') stats.timeout++;
    else if (type === 'kick') stats.kick++;
    else if (type === 'ban' || type === 'hackban') stats.ban++;
  });
  
  document.getElementById('totalCases').textContent = stats.total;
  document.getElementById('warningCount').textContent = stats.warning;
  document.getElementById('timeoutCount').textContent = stats.timeout;
  document.getElementById('kickCount').textContent = stats.kick;
  document.getElementById('banCount').textContent = stats.ban;
}

function normalizeType(type) {
  const typeMap = {
    'warn': 'Warning',
    'warning': 'Warning',
    'timeout': 'Timeout',
    'kick': 'Kick',
    'ban': 'Ban',
    'hackban': 'Hackban'
  };
  return typeMap[type.toLowerCase()] || type;
}

function getTypeClass(type) {
  const classMap = {
    'warn': 'warning',
    'warning': 'warning',
    'timeout': 'timeout',
    'kick': 'kick',
    'ban': 'ban',
    'hackban': 'hackban'
  };
  return classMap[type.toLowerCase()] || type.toLowerCase();
}

function displayCases(cases) {
  const container = document.getElementById('casesContainer');
  
  if (cases.length === 0) {
    container.innerHTML = `
      <div class="no-cases">
        <h2>📋 No cases found</h2>
        <p>No moderation cases match your current filters.</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = `
    <div class="table-container">
      <table class="cases-table">
        <thead>
          <tr>
            <th>Case #</th>
            <th>Type</th>
            <th>User</th>
            <th>Moderator</th>
            <th>Reason</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          ${cases.map(c => {
            const userName = escapeHtml(c.username || c.userName);
            const userAvatar = c.userAvatar || 'https://cdn.discordapp.com/embed/avatars/0.png';
            const modName = escapeHtml(c.moderatorName);
            const modAvatar = c.moderatorAvatar || 'https://cdn.discordapp.com/embed/avatars/1.png';
            const reason = escapeHtml(c.reason || 'No reason provided');
            const dateStr = new Date(c.timestamp).toLocaleString();
            
            return `<tr class="clickable-row" onclick='showCaseModal(${JSON.stringify(c).replace(/'/g, "&apos;")})'>
              <td class="case-number-cell">#${c.caseNumber}</td>
              <td class="type-cell"><span class="case-type ${getTypeClass(c.type)}">${normalizeType(c.type)}</span></td>
              <td class="user-cell">
                <img src="${userAvatar}" alt="${userName}" class="table-avatar">
                <span><a href="/user.html?id=${c.userId}" class="user-link">${userName}</a> <span class="user-id">(${c.userId})</span></span>
              </td>
              <td class="moderator-cell">
                <img src="${modAvatar}" alt="${modName}" class="table-avatar">
                <span>${modName}</span>
              </td>
              <td class="reason-cell">${reason}</td>
              <td class="date-cell">${dateStr}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function filterCases() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const typeFilter = document.getElementById('typeFilter').value.toLowerCase();
  const sortOrder = document.getElementById('sortOrder').value;
  
  let filtered = allCases.filter(c => {
    const matchesSearch = !searchTerm || 
      c.userName.toLowerCase().includes(searchTerm) ||
      c.userId.includes(searchTerm) ||
      c.moderatorName.toLowerCase().includes(searchTerm) ||
      c.reason.toLowerCase().includes(searchTerm);
    
    const matchesType = !typeFilter || c.type.toLowerCase() === typeFilter;
    
    return matchesSearch && matchesType;
  });
  
  filtered.sort((a, b) => {
    return sortOrder === 'desc' 
      ? b.caseNumber - a.caseNumber
      : a.caseNumber - b.caseNumber;
  });
  
  displayCases(filtered);
}

document.getElementById('searchInput').addEventListener('input', filterCases);
document.getElementById('typeFilter').addEventListener('change', filterCases);
document.getElementById('sortOrder').addEventListener('change', filterCases);

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login.html';
  } catch (error) {
    window.location.href = '/login.html';
  }
});

(async () => {
  if (await checkAuth()) {
    await loadCases();
  }
})();
