// Case modal functionality
let currentCase = null;

function showCaseModal(caseData) {
  currentCase = caseData;
  const modal = document.getElementById('caseModal');
  const modalContent = document.getElementById('caseModalContent');
  
  const canDelete = window.currentUser && window.currentUser.permissionLevel >= 4;
  
  modalContent.innerHTML = `
    <div class="modal-header">
      <h2>Case #${caseData.caseNumber}</h2>
      <button class="modal-close" onclick="closeCaseModal()">×</button>
    </div>
    
    <div class="modal-body">
      <div class="case-detail-section">
        <h3>Case Type</h3>
        <span class="case-type ${caseData.type.toLowerCase()}">${caseData.type.toUpperCase()}</span>
      </div>
      
      <div class="case-detail-section">
        <h3>User Information</h3>
        <div class="user-detail">
          <img src="${caseData.userAvatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}" 
               alt="${escapeHtml(caseData.username || caseData.userName)}" 
               class="detail-avatar">
          <div>
            <div class="detail-name">
              <a href="/user.html?id=${caseData.userId}" class="user-link">
                ${escapeHtml(caseData.username || caseData.userName)}
              </a>
            </div>
            <div class="detail-id">Discord ID: ${caseData.userId}</div>
          </div>
        </div>
      </div>
      
      <div class="case-detail-section">
        <h3>Moderator</h3>
        <div class="user-detail">
          <img src="${caseData.moderatorAvatar || 'https://cdn.discordapp.com/embed/avatars/1.png'}" 
               alt="${escapeHtml(caseData.moderatorName)}" 
               class="detail-avatar">
          <div>
            <div class="detail-name">${escapeHtml(caseData.moderatorName)}</div>
            <div class="detail-id">ID: ${caseData.moderatorId}</div>
          </div>
        </div>
      </div>
      
      <div class="case-detail-section">
        <h3>Reason</h3>
        <div class="reason-box">${escapeHtml(caseData.reason)}</div>
      </div>
      
      <div class="case-detail-section">
        <h3>Date & Time</h3>
        <div class="detail-text">${new Date(caseData.timestamp).toLocaleString('en-US', {
          dateStyle: 'full',
          timeStyle: 'long'
        })}</div>
      </div>
      
      ${caseData.severity ? `
        <div class="case-detail-section">
          <h3>Severity</h3>
          <div class="detail-text severity-${caseData.severity}">${caseData.severity.toUpperCase()}</div>
        </div>
      ` : ''}
      
      ${caseData.duration ? `
        <div class="case-detail-section">
          <h3>Duration</h3>
          <div class="detail-text">${caseData.duration}</div>
        </div>
      ` : ''}
    </div>
    
    <div class="modal-footer">
      ${canDelete ? `
        <button class="delete-btn" onclick="deleteCurrentCase()">
          🗑️ Delete Case
        </button>
      ` : ''}
      <button class="close-btn" onclick="closeCaseModal()">Close</button>
    </div>
  `;
  
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeCaseModal() {
  const modal = document.getElementById('caseModal');
  modal.style.display = 'none';
  document.body.style.overflow = 'auto';
  currentCase = null;
}

async function deleteCurrentCase() {
  if (!currentCase) return;
  
  if (!confirm(`Are you sure you want to delete Case #${currentCase.caseNumber}?\n\nThis action cannot be undone.`)) {
    return;
  }
  
  try {
    const response = await fetch(`/api/cases/${currentCase.caseNumber}`, {
      method: 'DELETE',
    });
    
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to delete case');
    }
    
    alert(`Case #${currentCase.caseNumber} has been deleted successfully.`);
    closeCaseModal();
    
    // Reload cases
    if (typeof loadCases === 'function') {
      await loadCases();
    } else {
      window.location.reload();
    }
  } catch (error) {
    alert(`Error deleting case: ${error.message}`);
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Close modal when clicking outside
window.addEventListener('click', (e) => {
  const modal = document.getElementById('caseModal');
  if (e.target === modal) {
    closeCaseModal();
  }
});

// Close modal on Escape key
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeCaseModal();
  }
});
