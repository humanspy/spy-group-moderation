import express from "express";
import { promises as fs } from "fs";
import bcrypt from "bcrypt";
import session from "express-session";
import createSqliteStore from "connect-sqlite3";
import { organizeCasesToFolder } from "./organize-cases.js";

const app = express();

// Session store
const SQLiteStore = createSqliteStore(session);

// Session middleware
app.use(
  session({
    store: new SQLiteStore({
      db: "sessions.db",
      dir: "./",
    }),
    secret:
      process.env.SESSION_SECRET ||
      "spy-group-case-viewer-secret-change-in-production",
    name: "caseViewerSession",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24, // 24 hours
    },
  }),
);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// ===== DATA FUNCTIONS =====

async function loadCases() {
  try {
    const data = await fs.readFile("./cases.json", "utf-8");
    const caseData = JSON.parse(data);
    if (!caseData.nextCaseNumber || typeof caseData.nextCaseNumber !== 'number') {
      if (caseData.cases && Array.isArray(caseData.cases) && caseData.cases.length > 0) {
        const maxCaseNumber = Math.max(...caseData.cases.map(c => c.caseNumber || 0));
        caseData.nextCaseNumber = maxCaseNumber + 1;
      } else {
        caseData.nextCaseNumber = 1;
      }
    }
    return caseData;
  } catch {
    return { nextCaseNumber: 1, cases: [] };
  }
}

async function saveCases(caseData) {
  await fs.writeFile("./cases.json", JSON.stringify(caseData, null, 2));
  try {
    await organizeCasesToFolder(caseData);
  } catch (error) {
    console.error('⚠️ Failed to sync cases folder:', error);
  }
}

async function deleteCase(caseNumber) {
  const caseData = await loadCases();
  const caseIndex = caseData.cases.findIndex(c => c.caseNumber === caseNumber);
  if (caseIndex === -1) return null;
  
  const deletedCase = caseData.cases[caseIndex];
  caseData.cases.splice(caseIndex, 1);
  await saveCases(caseData);
  return deletedCase;
}

async function loadUsers() {
  try {
    const data = await fs.readFile("./users.json", "utf-8");
    const usersObj = JSON.parse(data);
    // Convert object to array for compatibility
    return Object.values(usersObj);
  } catch {
    return [];
  }
}

async function getUserByDiscordId(discordId) {
  const users = await loadUsers();
  return users.find((u) => u.discordId === discordId);
}

async function getUserByUsername(username) {
  const users = await loadUsers();
  return users.find(
    (u) => u.username.toLowerCase() === username.toLowerCase(),
  );
}

// ===== AUTHENTICATION MIDDLEWARE =====

function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}

function requirePermission(level) {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    const userLevel = req.session.user.permissionLevel || 0;
    if (userLevel < level) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}

// ===== API ROUTES =====

// Login
app.post("/api/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const user = await getUserByUsername(username);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    req.session.user = {
      username: user.username,
      discordId: user.discordId,
      permissionLevel: user.permissionLevel,
      avatar: user.avatar,
      role: user.role,
      roleColor: user.roleColor,
    };

    res.json({ success: true, user: req.session.user });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get session
app.get("/api/session", requireAuth, (req, res) => {
  res.json({ user: req.session.user });
});

// Logout
app.post("/api/logout", (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Get all cases
app.get("/api/cases", requireAuth, async (req, res) => {
  try {
    const caseData = await loadCases();
    res.json({ cases: caseData.cases || [] });
  } catch (error) {
    console.error('Error loading cases:', error);
    res.status(500).json({ error: 'Failed to load cases' });
  }
});

// Get single case
app.get("/api/cases/:id", requireAuth, async (req, res) => {
  try {
    const caseNumber = parseInt(req.params.id);
    const caseData = await loadCases();
    const caseItem = caseData.cases.find(c => c.caseNumber === caseNumber);
    
    if (!caseItem) {
      return res.status(404).json({ error: 'Case not found' });
    }
    
    res.json({ case: caseItem });
  } catch (error) {
    console.error('Error loading case:', error);
    res.status(500).json({ error: 'Failed to load case' });
  }
});

// Delete case (requires admin permission)
app.delete("/api/cases/:id", requirePermission(4), async (req, res) => {
  try {
    const caseNumber = parseInt(req.params.id);
    const deletedCase = await deleteCase(caseNumber);
    
    if (!deletedCase) {
      return res.status(404).json({ error: 'Case not found' });
    }
    
    res.json({ success: true, deletedCase });
  } catch (error) {
    console.error('Error deleting case:', error);
    res.status(500).json({ error: 'Failed to delete case' });
  }
});

// Get user profile and cases
app.get("/api/user/:userId", requireAuth, async (req, res) => {
  try {
    const userId = req.params.userId;
    const caseData = await loadCases();
    
    // Find all cases for this user
    const userCases = caseData.cases.filter(c => c.userId === userId);
    
    if (userCases.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Get user info from the first case
    const firstCase = userCases[0];
    const user = {
      id: userId,
      username: firstCase.username || firstCase.userName,
      avatar: firstCase.userAvatar || 'https://cdn.discordapp.com/embed/avatars/0.png'
    };
    
    res.json({ user, cases: userCases });
  } catch (error) {
    console.error('Error loading user:', error);
    res.status(500).json({ error: 'Failed to load user' });
  }
});

// Redirect root to login
app.get("/", (req, res) => {
  if (req.session.user) {
    res.redirect("/cases.html");
  } else {
    res.redirect("/login.html");
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error("❌ Error:", err);
  res.status(500).json({ error: 'Internal server error' });
});

// Handle process errors
process.on("uncaughtException", (err) => {
  console.error("❌ Uncaught Exception:", err);
  console.error("Stack:", err.stack);
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("❌ Unhandled Rejection at:", promise);
  console.error("Reason:", reason);
});

// Start server
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(`\n🌐 Case Viewer running at http://0.0.0.0:${PORT}`);
  console.log(`📊 View cases in your browser\n`);
  console.log(`✅ Server ready and accepting connections`);
});

server.on("error", (err) => {
  console.error("❌ Server error:", err);
  if (err.code === "EADDRINUSE") {
    console.error(`Port ${PORT} is already in use`);
    process.exit(1);
  }
});
