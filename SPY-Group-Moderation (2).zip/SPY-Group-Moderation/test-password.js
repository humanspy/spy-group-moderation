import bcrypt from 'bcrypt';

const storedHash = "$2b$10$ML606wbdPJPD0fxbdIj1aOYna1dAKWIFEUTPlxSmwV6hJqOtvQG36";
const passwordToTest = "123456789";

bcrypt.compare(passwordToTest, storedHash, (err, result) => {
  if (err) {
    console.error("Error:", err);
    return;
  }
  
  console.log(`Password "${passwordToTest}" matches hash:`, result);
  
  if (!result) {
    console.log("\n⚠️ Password does NOT match the stored hash!");
    console.log("The password in users.json was hashed from a different password.");
  } else {
    console.log("\n✅ Password MATCHES! Login should work.");
  }
});
